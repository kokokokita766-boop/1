"use client";

import { useState } from "react";
import Image from "next/image";
import { Clock, Users, BookOpen, ChevronLeft, ChevronRight, Star, Sparkles } from "lucide-react";
import { storyParts, mainCharacters, seriesSummary, finalMessage, type Part, type Chapter, type Character } from "@/lib/story-data";

function HeroSection() {
  return (
    <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/20 via-background to-background" />
      <div className="absolute top-20 right-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-20 left-20 w-48 h-48 bg-accent/10 rounded-full blur-3xl animate-pulse delay-1000" />
      
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 text-primary mb-6">
          <Clock className="w-4 h-4" />
          <span className="text-sm font-medium">الأجزاء 2 - 3 - 4</span>
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold mb-4 text-foreground text-balance">
          لغز الساعة المفقودة
        </h1>
        
        <p className="text-xl md:text-2xl text-muted-foreground mb-8 text-balance">
          قصة بوليسية مشوقة للأطفال والشباب
        </p>
        
        <p className="text-lg text-foreground/80 max-w-2xl mx-auto leading-relaxed">
          تابع مغامرات الأصدقاء الخمسة في عوالم موازية، معارك العقل، ومواجهة الذات
        </p>
        
        <div className="flex flex-wrap justify-center gap-4 mt-8">
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-card border border-border">
            <BookOpen className="w-4 h-4 text-primary" />
            <span className="text-sm">بوليسي / مغامرة / خيال علمي</span>
          </span>
          <span className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-card border border-border">
            <Users className="w-4 h-4 text-accent" />
            <span className="text-sm">8-16 سنة</span>
          </span>
        </div>
      </div>
    </section>
  );
}

function CharacterCard({ character }: { character: Character }) {
  return (
    <div className="group relative p-6 rounded-xl bg-card border border-border hover:border-primary/50 transition-all duration-300">
      {character.image ? (
        <div className="w-20 h-20 rounded-full overflow-hidden mb-4 ring-2 ring-primary/30 mx-auto">
          <Image
            src={character.image}
            alt={character.name}
            width={80}
            height={80}
            className="w-full h-full object-cover"
          />
        </div>
      ) : (
        <div className={`w-20 h-20 rounded-full bg-gradient-to-br ${character.color} flex items-center justify-center mb-4 mx-auto`}>
          <span className="text-2xl font-bold text-white">{character.name[0]}</span>
        </div>
      )}
      <h3 className="text-xl font-bold text-foreground mb-1 text-center">{character.name}</h3>
      <p className="text-sm text-primary mb-3 text-center">{character.title}</p>
      <p className="text-sm text-muted-foreground leading-relaxed text-center">{character.description}</p>
    </div>
  );
}

function CharactersSection() {
  return (
    <section className="py-16 px-4 bg-secondary/30">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-2 text-foreground">الشخصيات الرئيسية</h2>
        <p className="text-center text-muted-foreground mb-12">الأصدقاء الخمسة الشجعان</p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
          {mainCharacters.map((character) => (
            <CharacterCard key={character.name} character={character} />
          ))}
        </div>
      </div>
    </section>
  );
}

function PartNavigation({ 
  parts, 
  activePart, 
  onSelectPart 
}: { 
  parts: Part[]; 
  activePart: number; 
  onSelectPart: (id: number) => void;
}) {
  return (
    <div className="flex flex-wrap justify-center gap-4 mb-12">
      {parts.map((part) => (
        <button
          key={part.id}
          onClick={() => onSelectPart(part.id)}
          className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
            activePart === part.id
              ? `bg-gradient-to-r ${part.color} text-white shadow-lg`
              : "bg-card border border-border text-foreground hover:border-primary/50"
          }`}
        >
          <span className="text-sm opacity-75">الجزء {part.id}</span>
          <span className="block font-bold">{part.title}</span>
        </button>
      ))}
    </div>
  );
}

function ChapterContent({ chapter }: { chapter: Chapter }) {
  const formatContent = (content: string) => {
    return content.split("\n\n").map((paragraph, idx) => {
      const formattedParagraph = paragraph
        .replace(/\*\*(.*?)\*\*/g, '<strong class="text-primary">$1</strong>')
        .replace(/> (.*)/g, '<blockquote class="border-r-4 border-primary pr-4 italic text-muted-foreground my-4">$1</blockquote>');
      
      return (
        <p
          key={idx}
          className="mb-4 leading-relaxed text-foreground/90"
          dangerouslySetInnerHTML={{ __html: formattedParagraph }}
        />
      );
    });
  };

  return (
    <div className="prose prose-invert max-w-none">
      {formatContent(chapter.content)}
    </div>
  );
}

function ChapterReader({ part }: { part: Part }) {
  const [currentChapter, setCurrentChapter] = useState(0);
  const chapter = part.chapters[currentChapter];

  return (
    <div className="bg-card rounded-2xl border border-border overflow-hidden">
      {/* Chapter Header */}
      <div className={`bg-gradient-to-r ${part.color} p-6`}>
        <div className="flex items-center justify-between">
          <div>
            <span className="text-white/80 text-sm">الفصل {chapter.number} من {part.chapters.length}</span>
            <h3 className="text-2xl font-bold text-white">{chapter.title}</h3>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setCurrentChapter(Math.max(0, currentChapter - 1))}
              disabled={currentChapter === 0}
              className="p-2 rounded-lg bg-white/20 text-white disabled:opacity-50 disabled:cursor-not-allowed hover:bg-white/30 transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            <button
              onClick={() => setCurrentChapter(Math.min(part.chapters.length - 1, currentChapter + 1))}
              disabled={currentChapter === part.chapters.length - 1}
              className="p-2 rounded-lg bg-white/20 text-white disabled:opacity-50 disabled:cursor-not-allowed hover:bg-white/30 transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Chapter Navigation */}
      <div className="flex overflow-x-auto gap-2 p-4 bg-secondary/50 border-b border-border">
        {part.chapters.map((ch, idx) => (
          <button
            key={ch.number}
            onClick={() => setCurrentChapter(idx)}
            className={`shrink-0 px-4 py-2 rounded-lg text-sm transition-all ${
              currentChapter === idx
                ? "bg-primary text-primary-foreground"
                : "bg-card text-muted-foreground hover:text-foreground"
            }`}
          >
            {ch.number}. {ch.title}
          </button>
        ))}
      </div>

      {/* Chapter Content */}
      <div className="p-6 md:p-8 max-h-[60vh] overflow-y-auto">
        <ChapterContent chapter={chapter} />
      </div>

      {/* Teaser for next part */}
      {currentChapter === part.chapters.length - 1 && part.teaser && (
        <div className="p-6 bg-gradient-to-r from-primary/10 to-accent/10 border-t border-border">
          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-primary shrink-0 mt-1" />
            <div>
              <p className="text-sm font-medium text-primary mb-1">يتبع في الجزء التالي:</p>
              <p className="text-foreground/80 italic">{part.teaser}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function NewCharactersSection({ characters }: { characters: Character[] }) {
  if (!characters || characters.length === 0) return null;
  
  return (
    <div className="mt-8 p-6 bg-secondary/30 rounded-xl border border-border">
      <h4 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
        <Star className="w-5 h-5 text-primary" />
        شخصيات جديدة في هذا الجزء
      </h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {characters.map((char) => (
          <div key={char.name} className="flex items-start gap-4 p-4 bg-card rounded-lg border border-border">
            {char.image ? (
              <div className="w-16 h-16 rounded-full overflow-hidden ring-2 ring-primary/30 shrink-0">
                <Image
                  src={char.image}
                  alt={char.name}
                  width={64}
                  height={64}
                  className="w-full h-full object-cover"
                />
              </div>
            ) : (
              <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${char.color} flex items-center justify-center shrink-0`}>
                <span className="text-lg font-bold text-white">{char.name[0]}</span>
              </div>
            )}
            <div>
              <h5 className="font-bold text-foreground">{char.name}</h5>
              <p className="text-sm text-primary">{char.title}</p>
              <p className="text-sm text-muted-foreground mt-1">{char.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StoryPartsSection() {
  const [activePart, setActivePart] = useState(2);
  const currentPart = storyParts.find((p) => p.id === activePart)!;

  return (
    <section className="py-16 px-4">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-2 text-foreground">فصول القصة</h2>
        <p className="text-center text-muted-foreground mb-8">اختر الجزء لقراءة الفصول</p>
        
        <PartNavigation parts={storyParts} activePart={activePart} onSelectPart={setActivePart} />
        
        {/* Part Description */}
        <div className="text-center mb-8">
          <p className="text-lg text-foreground/80">{currentPart.description}</p>
        </div>
        
        <ChapterReader part={currentPart} />
        
        {currentPart.newCharacters && (
          <NewCharactersSection characters={currentPart.newCharacters} />
        )}
      </div>
    </section>
  );
}

function SummarySection() {
  return (
    <section className="py-16 px-4 bg-secondary/30">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12 text-foreground">ملخص السلسلة الكاملة</h2>
        
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead>
              <tr className="border-b border-border">
                <th className="px-4 py-3 text-primary font-bold">الجزء</th>
                <th className="px-4 py-3 text-primary font-bold">العنوان</th>
                <th className="px-4 py-3 text-primary font-bold">الأحداث الرئيسية</th>
                <th className="px-4 py-3 text-primary font-bold">الشخصيات الجديدة</th>
              </tr>
            </thead>
            <tbody>
              {seriesSummary.map((item) => (
                <tr key={item.part} className="border-b border-border/50 hover:bg-card/50 transition-colors">
                  <td className="px-4 py-4 font-bold text-foreground">{item.part}</td>
                  <td className="px-4 py-4 text-foreground">{item.title}</td>
                  <td className="px-4 py-4 text-muted-foreground">{item.events}</td>
                  <td className="px-4 py-4 text-accent">{item.newCharacters}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

function FinalMessageSection() {
  return (
    <section className="py-20 px-4">
      <div className="max-w-3xl mx-auto text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-primary to-accent mb-8">
          <Sparkles className="w-8 h-8 text-white" />
        </div>
        
        <h2 className="text-3xl font-bold mb-8 text-foreground">العبر النهائية للسلسلة</h2>
        
        <blockquote className="text-xl leading-relaxed text-foreground/90 mb-8 p-8 bg-card rounded-2xl border border-border relative">
          <span className="absolute top-4 right-4 text-6xl text-primary/20 font-serif">&rdquo;</span>
          {finalMessage.quote}
        </blockquote>
        
        <p className="text-lg text-muted-foreground leading-relaxed p-6 bg-secondary/30 rounded-xl">
          {finalMessage.lesson}
        </p>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="py-8 px-4 border-t border-border bg-card/50">
      <div className="max-w-5xl mx-auto text-center">
        <p className="text-muted-foreground">
          ستة أصدقاء. ستة أبطال. مغامرات لا تنتهي.
        </p>
        <p className="text-sm text-muted-foreground/60 mt-2">
          والنجمة الجديدة في السماء... تنتظر من يكتشف سرها.
        </p>
      </div>
    </footer>
  );
}

export default function StoryPage() {
  return (
    <main className="min-h-screen bg-background">
      <HeroSection />
      <CharactersSection />
      <StoryPartsSection />
      <SummarySection />
      <FinalMessageSection />
      <Footer />
    </main>
  );
}
